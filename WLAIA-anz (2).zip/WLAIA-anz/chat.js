let apiKey = "";
let sortedResults = null;
// Load any saved state when the popup is opened
document.addEventListener('DOMContentLoaded', function () {
    chrome.storage.local.get('state', function (data) {
        if (data.state) {
            document.getElementById('response_container').innerHTML = data.state;
        }
    });
    chrome.storage.local.get('sortedResults', function (data) {
        if (data) {
            document.getElementById('sorted_list_container').innerHTML = data.sortedResults;
        }
    });
    chrome.storage.local.get('aiInput', function (data) {
        if (data) {
            apiKey = data.aiInput;
        }
    });
});

document.getElementById('submit_question').addEventListener('click', function () {
    const userInput = document.getElementById('user_input').value;

    generateResponse(userInput)
        .then(response => {
            document.getElementById('response_container').innerHTML = response;
            saveState();
            chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {question: userInput});
            });
        });
});


document.getElementById('response_container').addEventListener('click', function (event) {
    if (event.target.tagName === 'A') {
        event.preventDefault();
        navigateToURL(event.target.href);
    } else if (event.target.id === 'custom_search_submit') {
        const customSearchInput = document.getElementById('custom_search_input').value;
        const customSearchURL = `https://next.westlaw.com/Search/Results.html?searchType=quick&jurisdiction=ALLCASES&query=${encodeURIComponent(customSearchInput)}`;
        navigateToURL(customSearchURL);
    }
});

document.getElementById('submit_ai_input').addEventListener('click', function () {
    const privateKey = document.getElementById('ai_input').value;
    document.getElementById('ai_input').value = '';
    // Save private key
    chrome.storage.local.set({aiInput: privateKey});
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {aiInput: privateKey});
    });
    apiKey = privateKey;
});


document.getElementById('submit_headers').addEventListener('click', function () {
    const privateKey = document.getElementById('headers_input').value;
    document.getElementById('headers_input').value = '';
    // Save private key
    chrome.storage.local.set({headers: privateKey});
    apiKey = privateKey;
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {headers: privateKey});
    });
});

let userQuestion = "";


// Clear chat button event listener
document.getElementById('clear_chat').addEventListener('click', function () {
    chrome.storage.local.remove(['state', 'question'], function () {
        document.getElementById('response_container').innerHTML = '';
    });
});

function navigateToURL(url) {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {url: url});
    });
}

async function generateResponse(userInput) {
    userQuestion = userInput;
    const messages = generateQueryAnalysisNLGpt4Message_initial(userInput);
    const responseFromGpt = await processWithAzureOpenAI(messages)
    let responseText = `
	<div id="userQuestion">User Question: ${userInput}</div>
	Here are a few suggested search queries in order to start answering that question:
	<ul>`
    for (let i = 0; i < responseFromGpt.search_queries.length; i++) {
        responseText += `<li><a href="https://next.qed.westlaw.com/Search/Results.html?searchType=quick&jurisdiction=ALLCASES&query=${encodeURIComponent(responseFromGpt.search_queries[i])}">${responseFromGpt.search_queries[i]}</a></li>
		`;
    }

    responseText += `
	  </ul>
	  Or enter your desired search in the box below to begin with a custom search:
      <input id="custom_search_input" type="text">
      <button id="custom_search_submit">Submit Custom Search</button>`;


    return responseText;


}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log(sender.tab ? "from a content script:" + sender.tab.url : "from the extension");
        if (request.sortedResults)
            sortedResults = request.sortedResults;
            chrome.storage.local.set({sortedResults: sortedResults});
            sendResponse({farewell: "goodbye"});
            document.getElementById('sorted_list_container').innerHTML = sortedResults;
    }
);

async function processWithAzureOpenAI(messages) {


    const apiEndpoint = 'https://api.openai.com/v1/chat/completions';

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            model: "gpt-3.5-turbo-0613",//gpt-4-0613
            max_tokens: 1800,
            functions: generateFunctions(),
            temperature: 0.2
        }),
    });

    const data = await response.json();
    const assistantMessage = data.choices[0].message.function_call.arguments;
    const jsonString = assistantMessage.replace(/\n/g, "");
    const jsonObject = JSON.parse(jsonString);
    return jsonObject;
}

function generateFunctions() {
    // Modify the user message based on the scraped text
    functions = [
        {
            "name": "get_legal_search_results",
            "description": "Runs one to many natural language search queries on Westlaw Precision to find documents in order to answer a user legal question",
            "parameters": {
                "type": "object",
                "properties": {
                    "search_queries": {
                        "type": "array",
                        "description": "the natural language search query which will be used to find documents relevant to the user question",
                        "items": {
                            "type": "string"
                        }
                    }
                },
                "required": ["search_query"],
            },
        }
    ]
    return functions;
}


function generateQueryAnalysisNLGpt4Message_initial(text) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    const userMessage = `As a legal research expert, you excel at formulating natural language search queries for Westlaw Precision. The question below was provided by a lawyer performing legal research. The question was written as the input to a legal research ai.  generate a function call which will is likely to return all the relvant documents needed in order to answer the users legal question \n\n Question:\n ${text}`;

    const systemMessage = `
	You are an expert legal researcher who specializes in writing search queries for westlaw in order to answer legal research questions.  Make sure to include relevant refernces to possible statutes which could be applicable.
	`

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

function saveState() {
    const state = document.getElementById('response_container').innerHTML;
    chrome.storage.local.set({state: state});
}

