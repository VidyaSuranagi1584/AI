let buttonsInserted = false;
let headers = "";
let apiKey = "";
let question = "";
let aiState = {};
let docObj = {};
let allText = [];

function getQuestion() {
    if (aiState && aiState.chatMessages && aiState.chatMessages.length > 1) {
        question = aiState.chatMessages.filter(message => message.question).map(message => message.text).join(" ");
    }
}

window.onload = function () {
    buttonsInserted = false;
    chrome.runtime.sendMessage({getAIBackgroundState: true}, function (response) {
        if (response && response.aiState) {
            headers = response.aiHeaders;
            apiKey = response.aiInput;
            aiState = response.aiState;
            getQuestion();
            if (question && question.length > 0 && window.location.pathname.startsWith("/Document/")) {
                extractDocumentContent();
                if (!buttonsInserted) {
                    setTimeout(function () {
                        if (!buttonsInserted) {
                            // Get the user question on each page load
                            chrome.storage.local.get('question', function (data) {
                                if (data.question) {
                                    insertButtons(data.question);
                                }
                            });
                        }
                    }, 3000);
                }
                if (!buttonsInserted) {
                    setTimeout(function () {
                        if (!buttonsInserted) {
                            // Get the user question on each page load
                            chrome.storage.local.get('question', function (data) {
                                if (data.question) {
                                    insertButtons(data.question);
                                }
                            });
                        }
                    }, 7000);
                }
                if (!buttonsInserted) {
                    setTimeout(function () {
                        if (!buttonsInserted) {
                            // Get the user question on each page load
                            chrome.storage.local.get('question', function (data) {
                                if (data.question) {
                                    insertButtons(data.question);
                                }
                            });
                        }
                    }, 10000);
                }
                if (!buttonsInserted) {
                    setTimeout(function () {
                        if (!buttonsInserted) {
                            // Get the user question on each page load
                            chrome.storage.local.get('question', function (data) {
                                if (data.question) {
                                    insertButtons(data.question);
                                }
                            });
                        }
                    }, 15000);
                }
                chrome.storage.local.get('aiInput', function (data) {
                    if (data.aiInput) {
                        apiKey = data.aiInput;
                    }
                });
                chrome.storage.local.get('headers', function (data) {
                    if (data.headers) {
                        headers = data.headers;
                    }
                });
            }
        }
    });


};

chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.url) {
            window.location.href = request.url;
        } else if (request.question) {
            chrome.storage.local.set({question: request.question});
            insertButtons(request.question);
        } else if (request.aiInput) {
            chrome.storage.local.set({aiInput: request.aiInput});
            apiKey = request.aiInput;
        } else if (request.headers) {
            chrome.storage.local.set({headers: request.headers});
            headers = request.headers;
        }
    }
);

function insertButtons(question) {
    const olElements = document.querySelectorAll('ol.co_searchResult_list');
    if (olElements && olElements.length > 0 && !buttonsInserted) {
        const headerElement = document.querySelector('div.co_search_result_heading_content');
        if (headerElement && !buttonsInserted) {
            const headerButton = document.createElement('button');
            headerButton.className = "co_tbButton";
            headerButton.textContent = `Generate search result list relevance analysis for "${question}"`;
            headerButton.addEventListener('click', () => generateSearchResultListRelevanceAnalysis(question));
            headerElement.appendChild(headerButton);
        }
        buttonsInserted = true;
        for (let h = 0; h < olElements.length; h++) {
            for (let i = 0; i < olElements[h].children.length; i++) {
                const button = document.createElement('button');
                button.textContent = `Add Document to Selected Documents List"`;
                button.className = "co_tbButton";
                button.addEventListener('click', () => sendResultItemToSelectedList(question, olElements[h].children[i]));
                olElements[h].children[i].insertBefore(button, olElements[h].children[i].children[0]);
            }
        }

    }
}

async function extractDocumentContent() {
    // Define your classes and corresponding object keys
    let classToKey = {
        "co_cites": "parallelCites",
        "co_title": "title",
        "co_synopsis": "synopsis",
        "co_headnotes": "headnotes",
        "co_attorneyBlock": "attornies",
        "co_opinionBlock": "opinion",
        "co_section": "docContent",
    };

    // Initialize your result document object
    docObj = {};
    allText = [];
    // Loop over each class/key pair in your object
    for (let cls in classToKey) {

        // Get all elements with this class
        let elements = document.getElementsByClassName(cls);

        // If elements are found, extract their text and save to the object
        if (elements.length > 0) {
            if (elements.length === 1) {
                docObj[classToKey[cls]] = elements[0].innerText;
                allText.push(elements[0].innerText);
            } else {
                docObj[classToKey[cls]] = Array.from(elements, el => el.innerText);
                allText.push(...docObj[classToKey[cls]]);
            }
        }
    }

    if (allText.length < 100) {
        let elements = document.getElementsByClassName("co_document");

        // If elements are found, extract their text and save to the object
        if (elements.length > 0) {
            if (elements.length === 1) {
                docObj["docContent"] = elements[0].innerText;
                allText.push(elements[0].innerText);
            } else {
                docObj["docContent"] = Array.from(elements, el => el.innerText);
                allText.push(...docObj["docContent"]);
            }
        }
    }

    let elements = document.getElementsByClassName("co_locateSnippet");

    docObj["snippets"] = Array.from(elements, el => el.parentElement.innerText);

    console.log(docObj);

    if (!allText || allText.length == 0) {
        return;
    }
    chrome.runtime.sendMessage({documentObject: docObj}, function (response) {
        console.log(response.farewell);
    });

    // locate the target div
    let targetDiv = document.querySelector('.co_title');
    if (!targetDiv) {
        targetDiv = document.querySelector('.Document-header');
    }
    if (!targetDiv) {
        targetDiv = document.querySelector('.co_document');
    }

// create new div
    var newDiv = document.createElement('div');
    newDiv.innerHTML = `
  <div class="co_contentBlock co_briefItState co_synopsis">
    <h2 id="co_ai_summary" class="co_printHeading">AI Generated Relevance Information:</h2>
    <div>
      <div class="co_paragraph">
        <h2 id="co_synopsis" class="co_printHeading">Relevance summary based on best portions:</h2>
        <div class="co_paragraphText" id="aiSummary">
        Generating AI summary of best portions...
        </div>
      </div>
      <div class="co_paragraph">
        <h2 id="co_synopsis" class="co_printHeading">Relevance summary based on full document:</h2>
        <div class="co_paragraphText" id="aiFullSummary">
            <button class="co_tbButton" id="aiLoadFullSummaryButton">Generate Summary Based on Whole Document</button>
        </div>
      </div>
    </div>
  </div>`;

// insert the new div immediately after the target div
    if (targetDiv.nextSibling && targetDiv.nextSibling.nextSibling) {
        targetDiv.parentNode.insertBefore(newDiv, targetDiv.nextSibling.nextSibling);
    } else if (targetDiv.nextSibling) {
        targetDiv.parentNode.insertBefore(newDiv, targetDiv.nextSibling);
    } else if (targetDiv) {
        targetDiv.parentNode.appendChild(newDiv);
    }
    // Get the div position
    var position = newDiv.getBoundingClientRect();

// Scroll to the position a bit above the div
    window.scrollTo(0, position.top-250);
    let summaryElement = document.getElementById('aiSummary');
    summaryElement.classList.add('pulse')

    let tocElements = document.getElementsByClassName('TocList');
    let aiTocEntry = `
                <li class="TocEntry" id="tocItem_ai_summary" role="treeitem" aria-selected="false" tabindex="-1">
<div class="TocEntryWrapper">
<div class="TocEntryMargin">
</div>
<div class="TocEntryContent">
<a focushighlight_toc_id="co_ai_summary" href="#co_ai_summary" title="AI Relevance Summary" aria-label="AI Relevance Summary" data-anchorid="co_ai_summary" tabindex="-1" class="co_link"><span>AI Relevance Summary</span></a>
</div>
</div>
</li>
    `;
    if (tocElements && tocElements.length > 0) {
        let parser = new DOMParser();
        let doc = parser.parseFromString(aiTocEntry, 'text/html');
        let element = doc.body.firstChild;
        tocElements[0].insertBefore(element, tocElements[0].children[0]);
    }

    let headerButton = document.getElementById('aiLoadFullSummaryButton');
    headerButton.addEventListener('click', () => generateFullSummary());

    let summaryMessage = generateSnippetSummaryMessage(docObj["snippets"], docObj["title"], docObj["synopsis"], question);
;
    await streamChatCompletionWithOpenAI(summaryMessage, [], 'gpt-4-8k', 1500, 0.2, summaryElement);


}

async function generateFullSummary() {
    let summaryElement = document.getElementById('aiFullSummary');
    summaryElement.innerHTML = '';
    summaryElement.innerHTML = "Generating summary based on full text of the document...";
    summaryElement.classList.add('pulse');
    let chunks = chunkString(allText.join("... ..."), 10000, 800);
    let chunkSummaryMessages = [];
    chunks.forEach((chunk, index) => {
        let chunkText = `Title: ${docObj.title}`;
        if (docObj["synopsis"] && docObj["synopsis"].length > 0) {
            chunkText += ` \t\t Synopsis: ${docObj["synopsis"]}`;
        }
        chunkText += ` \t\t Document Excerpt: ${chunk}`;
        chunkSummaryMessages.push(generateDocChunkSummaryMessage(chunkText, question));
    });

    let parallelCount = 10;

    // Split docs into chunks of 5 items each
    let parallelMessages = Array(Math.ceil(chunkSummaryMessages.length / parallelCount)).fill().map((_, index) => index * parallelCount).map(begin => chunkSummaryMessages.slice(begin, begin + parallelCount));
    let summaryResponses = [];
    for (let messages of parallelMessages) {
        let promises = messages.map(async message => {
            return chatCompletionWithAzureOpenAI(message, [], 'gpt-35-turbo', 400, 0.2);
        });

        try {
            summaryResponses.push(...await Promise.all(promises));
        } catch (err) {
            console.error(err);
        }
    }
    let summaries = summaryResponses.map((response, index) => {
        return response.choices[0].message.content;
    });

    let finalSummaryMessage = generateDocSummaryMessage(summaries, docObj["title"], docObj["synopsis"], question);
    await streamChatCompletionWithOpenAI(finalSummaryMessage, [], 'gpt-4-32k', 1500, 0.2, summaryElement);
}

function generateResultItemRelevanceAnalysis(question, listItemContent) {
    // Implement the analysis generation logic here
    const anchor = listItemContent.querySelector('a.draggable_document_link');
    let docGuid = anchor.getAttribute("docguid");
    console.log('DocGuid:', docGuid);
    console.log('Question:', question);
    console.log('List item content:', listItemContent);
}

async function generateSearchResultListRelevanceAnalysis(question) {
    // Implement the analysis generation logic here
    let queryParams = window.location.search.split("&");
    let searchId = "";
    let query = "";
    let jurisdiction = "";
    for (let i = 0; i < queryParams.length; i++) {
        if (queryParams[i].startsWith("searchId")) {
            searchId = queryParams[i].split("=")[1];
        } else if (queryParams[i].startsWith("query")) {
            query = queryParams[i].split("=")[1];
        } else if (queryParams[i].startsWith("jurisdiction")) {
            jurisdiction = queryParams[i].split("=")[1];
        }
    }
    let url = "https://" + window.location.hostname + "/Search/v1/results?query=" + query + "&jurisdiction=" + jurisdiction + "&result=" + searchId + "&searchId=" + searchId + "&FO=true&clientId=TEST&resultsPerPage=5&detailLevel=3&eligibleForDelivery=true";


    let casesResults = await fetch(url + "&type=CASE", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    });

    let statuteResults = await fetch(url + "&type=STATUTE", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    });
    let regulationResults = await fetch(url + "&type=REGULATION", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    });
    let secondarySources = await fetch(url + "&type=ANALYTICAL", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    });
    const caseData = await casesResults.json();
    const statuteData = await statuteResults.json();
    const regData = await regulationResults.json();
    const secondaryData = await secondarySources.json();

    let docs = [];
    if (caseData && caseData.resultSections && caseData.resultSections.length > 0 && caseData.resultSections[0].listItems && caseData.resultSections[0].listItems.length > 0) {
        docs.push(...caseData.resultSections[0].listItems);
    }
    if (statuteData && statuteData.resultSections && statuteData.resultSections.length > 0 && statuteData.resultSections[0].listItems && statuteData.resultSections[0].listItems.length > 0) {
        docs.push(...statuteData.resultSections[0].listItems);
    }
    if (regData && regData.resultSections && regData.resultSections.length > 0 && regData.resultSections[0].listItems && regData.resultSections[0].listItems.length > 0) {
        docs.push(...regData.resultSections[0].listItems);
    }
    if (secondaryData && secondaryData.resultSections && secondaryData.resultSections.length > 0 && secondaryData.resultSections[0].listItems && secondaryData.resultSections[0].listItems.length > 0) {
        docs.push(...secondaryData.resultSections[0].listItems);
    }
    let embeddings = [];
    for (let i = 0; i < docs.length; i++) {
        let textForEmbedding = "";
        if (docs[i].snippets && docs[i].snippets.length > 0) {
            for (let j = 0; j < docs[i].snippets.length; j++) {
                textForEmbedding += docs[i].snippets[j].snippetFragment.replace(/<[^>]*>/g, '');
            }
        }
        if (docs[i].summary) {
            textForEmbedding += "\n\n" + docs[i].summary.replace(/<[^>]*>/g, '');
        }
        docs[i].textForEmbedding = textForEmbedding;
        docs[i].embedding = await getEmbeddingAzureOpenAI(textForEmbedding);
        embeddings.push(docs[i].embedding);
    }
    let questionEmbedding = await getEmbeddingAzureOpenAI(question);
    let sortedResults = sortBasedOnSimilarity(docs, questionEmbedding);
    chrome.storage.local.set({sortedResults: sortedResults});

    console.log('searchId:', searchId);
    console.log('Question:', question);
    console.log('Sorted Results:', sortedResults);
    chrome.runtime.sendMessage({sortedResults: sortedResults}, function (response) {
        console.log(response.farewell);
    });
}

function getHeaders() {
    // Split the string into lines
    let headerLines = headers.split('\n');

    // Initialize an empty object to hold the headers
    let headersObject = {};

    // Iterate over the lines
    for (let line of headerLines) {
        // Split the line into key and value
        let [key, value] = line.split(': ');

        // If both key and value exist, add them to the headers object
        if (key && value) {
            headersObject[key] = value;
        }
    }
    headersObject["Accept"] = "application/json";
    headersObject["Accept-Language"] = "en-US";
    return headersObject;
}

async function processWithAzureOpenAI(messages) {
    /*const apiEndpoint = 'https://api.openai.com/v1/chat/completions';

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            model: "gpt-3.5-turbo-0613",//gpt-4-0613
            max_tokens: 1800,
            functions: generateFunctions(),
            temperature: 0.2
        }),
    });*/
    let model = "gpt-35-turbo";//gpt-4-0613
    const apiEndpoint = `https://oai-aalp-nonprod-eastus-001.openai.azure.com/openai/deployments/${model}/chat/completions`;

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            max_tokens: 800,
            temperature: 0.2
        }),
    });

    const data = await response.json();
    const assistantMessage = data.choices[0].message.function_call.arguments;
    const jsonString = assistantMessage.replace(/\n/g, "");
    return JSON.parse(jsonString);
}

async function chatCompletionWithAzureOpenAI(messages, functions = [], model = 'gpt-35-turbo', maxTokens = 1000, temperature = 0.2, timeout = 60000) {
    //const apiEndpoint = 'https://api.openai.com/v1/chat/completions';
    const apiEndpoint = `https://openai-ras.nonprod.thomsonreuters.com/openai/deployments/${model}/chat/completions?api-version=2023-07-01-preview`;
    let maxRetry = 5;
    let retries = 0;
    while (retries < maxRetry)
    {
        retries++;
        if (retries > 1) {
            await delay(retries * 2000)
        }
        try {
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Request timed out')), timeout)
            );

            /*const response = await fetch(apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    //"api-key": `${apiKey}`,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    messages: messages,
                    model: model,//gpt-4-0613
                    max_tokens: maxTokens,
                    temperature: temperature
                }),
            });*/


            const response = await fetch(apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    //"api-key": `${apiKey}`,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    messages: messages,
                    max_tokens: 800,
                    temperature: 0.2
                }),
            });
            let responseJson = await response.json();
            if (responseJson && responseJson.choices && responseJson.choices.length > 0) {
                return responseJson;
            }
        }catch (err) {
            console.error(err);
        }

    }



}

function delay(delayInMilliseconds) {
    // Return a promise
    return new Promise(resolve => {
        // Set up the delay
        setTimeout(resolve, delayInMilliseconds);
    });
}

async function streamChatCompletionWithOpenAI(messages, functions = [], model = 'gpt-35-turbo', maxTokens = 1000, temperature = 0.2, element) {
    /*const apiEndpoint = 'https://api.openai.com/v1/chat/completions';

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            model: model,//gpt-4-0613
            max_tokens: maxTokens,
            temperature: temperature,
            stream: true
        }),
    })*/
    let isElementCleared = false;
    const apiEndpoint = `https://openai-ras.nonprod.thomsonreuters.com/openai/deployments/${model}/chat/completions?api-version=2023-07-01-preview`;
    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            max_tokens: 800,
            temperature: 0.2,
            stream: true
        }),
    }).then(response => {

        const reader = response.body.getReader();

        reader.read().then(async function process({ done, value }) {
            if (done) {
                console.log('Stream complete');
                return;
            }
            const decoder = new TextDecoder();
            const decodedChunk = decoder.decode(value);
            // Clean up the data
            const lines = decodedChunk
                .split("\n")
                .map((line) => line.replace("data: ", ""))
                .filter((line) => line.length > 0)
                .filter((line) => line !== "[DONE]")
                .map((line) => { try {return JSON.parse(line)}catch(error){return {}}});

            // Destructuring!
            for (const line of lines) {
                if (line.choices && line.choices.length > 0) {
                    const {
                        choices: [
                            {
                                delta: {content},
                            },
                        ],
                    } = line;

                    if (content) {
                        let splitContent = content.split(" ");
                        for (let i = 0; i < splitContent.length; i++) {
                            await delay(35);
                            if (!isElementCleared) {
                                element.innerHTML = "";
                                element.classList.remove('pulse');
                                isElementCleared = true;
                            }
                            element.innerHTML += splitContent[i].replace("\n", "<br><br>") + (i < splitContent.length - 1 ? " " : "");
                        }
                    }
                }
            }

            // Read the next chunk
            return reader.read().then(process);
        });
    }).catch(error => console.error(error));
}

async function getEmbeddingAzureOpenAI(input) {
    //const apiEndpoint = 'https://api.openai.com/v1/embeddings';
    let maxRetry = 5;
    let retries = 0;

    const apiEndpoint = `https://openai-ras.nonprod.thomsonreuters.com/openai/deployments/text-embedding-ada-002/embeddings?api-version=2023-05-15`;



    while (retries < maxRetry) {
        retries++;
        if (retries > 1) {
            await delay(retries * 2000)
        }
        try {
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Request timed out')), 10000)
            );
            /*const response = await fetch(apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    //"api-key": `${apiKey}`,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    input: input,
                    model: "text-embedding-ada-002",
                }),
            });*/
            const response = await fetch(apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    //"api-key": `${apiKey}`,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    input: input
                }),
            });

            const data = await response.json();
            if (data && data.data && data.data[0] && data.data[0].embedding)
                updateProgressBar();
            return data.data[0].embedding;
        } catch (error) {
            console.log(error);
        }
    }
}

function cosinesim(A, B) {
    var dotproduct = 0;
    var mA = 0;
    var mB = 0;

    for (var i = 0; i < A.length; i++) {
        dotproduct += A[i] * B[i];
        mA += A[i] * A[i];
        mB += B[i] * B[i];
    }

    mA = Math.sqrt(mA);
    mB = Math.sqrt(mB);
    return dotproduct / (mA * mB);
}

function sortBasedOnSimilarity(arr, questionEmbedding) {
    // Calculate similarity and add to each object
    arr = arr.map(item => {
        return {
            ...item,
            similarity: cosinesim(item.embedding, questionEmbedding)
        };
    });

    // Sort array in descending order based on similarity
    arr.sort((a, b) => {
        return b.similarity - a.similarity;
    });

    return arr;
}

function chunkString(str, chunkCharSize, chunkOverlapSize) {
    const chunks = [];
    let currentIndex = 0;

    while (currentIndex < str.length) {
        let endIndex = Math.min(currentIndex + chunkCharSize, str.length);
        let subStr = str.substring(currentIndex, endIndex);

        // Look for specific break points and adjust endIndex accordingly
        let dblNewLineIdx = subStr.lastIndexOf("\n\n");
        let newLineIdx = subStr.lastIndexOf("\n");
        let multiSpaceIdx = subStr.lastIndexOf("  ");
        let spaceIdx = subStr.lastIndexOf(" ");
        let minSize = Math.ceil(chunkCharSize * 0.9);

        if (dblNewLineIdx >= minSize) {
            endIndex = currentIndex + dblNewLineIdx;
        } else if (newLineIdx >= minSize) {
            endIndex = currentIndex + newLineIdx;
        } else if (multiSpaceIdx >= minSize) {
            endIndex = currentIndex + multiSpaceIdx;
        } else if (spaceIdx >= minSize) {
            endIndex = currentIndex + spaceIdx;
        } else {
            endIndex = currentIndex + minSize > str.length ? str.length : currentIndex + minSize;
        }

        chunks.push(str.substring(currentIndex, endIndex));

        // Determine start of next chunk

        currentIndex = endIndex < str.length ? endIndex - chunkOverlapSize : endIndex;

        // Find nearest space to the boundary
        if (currentIndex < str.length) {
            let maxInset = 100;
            let inset = 0;
            while (inset < maxInset && str.charAt(currentIndex) !== " " && currentIndex < str.length) {
                currentIndex++;
                inset++;
            }
        }
    }

    return chunks;
}

function generateDocSummaryMessage(summaries, title, synopsis, searchQuery) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    let userMessage = `You are an expert legal researcher trying to assist a lawyer using Westlaw to determine whether a search result item is worth further investigation. Below is a set of excerpt summaries from a single case, statute, regulation or secondary source along with its title. Please provide an analysis of how this document is relevant to the users legal research question and provide a very detailed combined summary of the excerpt summaries and how they may be related or differ from the legal research question, based on the provided synopsis and excerpt summaries. If a synopsis is present, identify which part of the synopsis is most relevant to the legal research question. If the available information does not directly address the question posed, include in the summary any details that may be analogous to the issues posed in the search query. If the document contains details about the court, jurisdiction and parties involved make sure to include them in your summary.\n\n Question: ${searchQuery} \n\n Document Title: ${title}`;
    if (synopsis && synopsis.length > 0) {
        userMessage += ` \t\t Document Synopsis: ${synopsis}`;
    }
    userMessage += ` \t\t Document Excerpt Summaries: ${summaries.join("... ...")}`;

    const systemMessage = `You are an AI that provides helpful information based on the given text. You act and respond like an expert legal researcher.`;

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

function generateSnippetSummaryMessage(snippets, title, synopsis, searchQuery) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    let userMessage = `You are an expert legal researcher trying to assist a lawyer using Westlaw to determine whether a search result item is worth further investigation. Below is a set of snippets from a single case, statute, regulation or secondary source along with its title and in some cases a short synopsis. Please provide an analysis of how this document is relevant to the users legal research question and provide a very detailed combined summary of the provided snippets and how they may be related or differ from the legal research question. If a synopsis is present, identify which part of the synopsis is most relevant to the legal research question. If the available information does not directly address the question posed, include in the summary any details that may be analogous to the issues posed in the search query. If the document contains details about the court, jurisdiction and parties involved please preserve them in your summary.\n\n Question: ${searchQuery} \n\n Document Title: ${title}`;
    if (synopsis && synopsis.length > 0) {
        userMessage += ` \t\t Document Synopsis: ${synopsis}`;
    }
    userMessage += ` \t\t Document Snippets: ${snippets.join("... ...").slice(0, 25000)}`;

    const systemMessage = `You are an AI that provides helpful information based on the given text. You act and respond like an expert legal researcher.`;

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

function generateDocChunkSummaryMessage(chunkText, searchQuery) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    const userMessage = `You are an expert legal researcher trying to assist a lawyer using Westlaw to determine whether a search result item is worth further investigation. Below is an excerpt from a single case, statute regulation or secondary source along with its title, and in some cases a synopsis. Provide a summary of the text as it relates to the provided legal research question.  If the available information does not directly address the question posed, include in the summary any details that may be analogous to the issues posed in the search query. If the document contains details about the court, jurisdiction and parties involved please preserve them in your summary. \n\n Question:\n ${searchQuery} \n\n Document Excerpt: ${chunkText}`;

    const systemMessage = `You are an AI that provides helpful information based on the given text. You act and respond like an expert legal researcher.`;

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}