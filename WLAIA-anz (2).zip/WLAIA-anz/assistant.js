// Object to hold our application state
let aiState = {
    chatMessages: [],
    possibleDocuments: [],
    displayedPossibleDocuments:[],
    possibleDocumentSort: 'relevance',
    selectedDocuments: [],
    currentQuestion: '',
    currentQuestionEmbedding: []
};
let apiKey = "";
let aiHeaders = "";
let westlawHost = "";
let inRefine = false;
let inSearch = false;
let progressIterator = 0;
let progressTotal = 0;
let progressElement = null;
let userElementForPulse = null;
let inPulse = false;

const legalSearchFunction = {
    "name": "get_legal_search_results",
    "description": "Runs 1 to 5 natural language search queries on Westlaw Australia to find documents in order to answer a user legal question. Make sure to include references to possible statutes which could be applicable. Do not include references to document types (caselaw, statutes, etc.) in the queries as all document types we be searched.  Do not include states in the search queries instead if the query should be limited to specific states return those as a list of 2 letter state abbreviations in the corresponding states array.",
    "parameters": {
        "type": "object",
        "properties": {
            "search_queries": {
                "type": "array",
                "description": "the natural language search query which will be used to find documents relevant to the user question. Make sure to include references to possible statutes which could be applicable. Do not include references to document types (caselaw, statutes, etc.) in the queries as all document types we be searched.  Do not include states in the search queries instead if the query should be limited to specific states return those as a list of 2 letter state abbreviations in the corresponding states array.",
                "items": {
                    "type": "object",
                    "properties": {
                        "search_query": {
                            "type": "string",
                            "description": "the natural language search query which will be used to find documents relevant to the user question. Make sure to include references to possible statutes which could be applicable.",
                        },
                        "states_if_needed": {
                            "type": "array",
                            "description": "a list of 2 letter state abbreviations which will be used to limit the search to documents from those states",
                            "items": {
                                "type": "string"
                            }
                        }
                    },
                }
            }
        },
        "required": ["search_queries"]
    }
}

const precisionSearchFunction = {
    "name": "get_precision_legal_search_results",
    "description": "Runs 1 to 5 natural language search queries on Westlaw Australia to find documents in order to answer a user legal question. In addition to a query a precision search has a set of optional categories to further target the search result.  Make sure to include references to possible statutes which could be applicable. Do not include references to document types (caselaw, statutes, etc.) in the queries as all document types we be searched.  Do not include states in the search queries instead if the query should be limited to specific states return those as a list of 2 letter state abbreviations in the corresponding states array.",
    "parameters": {
        "type": "object",
        "properties": {
            "search_queries": {
                "type": "array",
                "description": "the natural language search query which will be used to find documents relevant to the user question. Make sure to include references to possible statutes which could be applicable. Do not include references to document types (caselaw, statutes, etc.) in the queries as all document types we be searched.  Do not include states in the search queries instead if the query should be limited to specific states return those as a list of 2 letter state abbreviations in the corresponding states array.",
                "items": {
                    "type": "object",
                    "properties": {
                        "search_query": {
                            "type": "string",
                            "description": "the natural language search query which will be used to find documents relevant to the user question. Make sure to include references to possible statutes which could be applicable.",
                        },
                        "states_if_needed": {
                            "type": "array",
                            "description": "a list of 2 letter state abbreviations which will be used to limit the search to documents from those states",
                            "items": {
                                "type": "string"
                            }
                        },
                        "area_of_law": {
                            "type": "array",
                            "description": "Find cases from a specific legal subject matter to ensure the legal issues, facts and claims are arising in the correct context. Examples: Commercial Law or Federal Civil Procedure",
                            "items": {
                                "type": "string"
                            }
                        },
                        "legal_issue": {
                            "type": "array",
                            "description": "Use Precision Research to quickly find cases involving your specific legal question and the related outcome on that issue. Example: Legal Issue: Subject Matter Jurisdiction > Sovereign Immunity Outcome: Found",
                            "items": {
                                "type": "string"
                            }
                        },
                        "cause_of_action": {
                            "type": "array",
                            "description": "Find legal claims that allow parties to seek judicial relief, which can help clarify a legal issue or surface other related claims. Examples: Breach of Contract or Unjust Enrichment",
                            "items": {
                                "type": "string"
                            }
                        },
                        "motion_type": {
                            "type": "array",
                            "description": "Find cases that dispose of the motion in which you're interested, including specific outcomes at trial and appeal. Example: Motion for Summary Judgment > Denied",
                            "items": {
                                "type": "string"
                            }
                        },
                        "governing_law": {
                            "type": "array",
                            "description": "Find cases involving a specific governing law that is relevant to the court's determination on a legal issue. Examples: Americans with Disabilities Act or Uniform Commercial Code",
                            "items": {
                                "type": "string"
                            }
                        },
                        "industry_type": {
                            "type": "array",
                            "description": "Find cases that involve legal issues or claims relevant to a specific industry or field of business. Examples: Banking and Financial Services, Insurance, or Real Estate",
                            "items": {
                                "type": "string"
                            }
                        },
                        "party_type": {
                            "type": "array",
                            "description": "Search or filter to find cases that include parties relevant to your current matter. Examples: Accountant or Mortgagor",
                            "items": {
                                "type": "string"
                            }
                        },
                        "material_facts": {
                            "type": "array",
                            "description": "Find cases that include your key terms in the facts that were most pertinent to the court's resolution of a legal dispute.",
                            "items": {
                                "type": "string"
                            }
                        },
                    },
                }
            }
        },
        "required": ["search_queries"]
    }
}

const refineQueryFunction = {
    "name": "refine_query",
    "description": "sends a set of questions back to the user so they can add additional details needed in order to run an effective search",
    "parameters": {
        "type": "object",
        "properties": {
            "questions_for_user_to_refine_task_definition": {
                "type": "array",
                "description": "a list of questions which will be posed to the user so they can provide additional details needed to define their task",
                "items": {
                    "type": "string"
                }
            }
        },
        "required": ["questions_for_user_to_refine_task_definition"]
    }
}

const addToKeepListFunction = {
    "name": "add_to_keep_list",
    "description": "Adds a document or set of documents to the users keep list",
    "parameters": {
        "type": "object",
        "properties": {
            "specific_documents_referenced": {
                "type": "array",
                "description": "An array of identifiers for any specific documents referenced in the request to add to keep list",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "the title of the document referenced by the user"
                        },
                        "citation": {
                            "type": "string",
                            "description": "the citation of the document referenced by the user"
                        },
                        "guid": {
                            "type": "string",
                            "description": "the guid of the document referenced by the user"
                        }
                    }
                }
            }
        },
        "required": ["specific_documents_referenced"],
    }
}

const runUserSearchFunction = {
    "name": "run_user_search",
    "description": "takes a search query given by a user and runs the search to find relevant documents",
    "parameters": {
        "type": "object",
        "properties": {
            "search_query": {
                "type": "string",
                "description": "The search query given by the user in order to find relevant documents"
            }
        },
        "required": ["search_query"],
    }
}

const seeMoreRelevantDocumentsFunction = {
    "name": "see_more_relevant_documents",
    "description": "expands the list of available documents shown to the user to include more relevant documents",
    "parameters": {
        "type": "object",
        "properties": {
            "doc_count": {
                "type": "number",
                "description": "The number of additional documents the user would like to see if requested."
            }
        }
    }
}

const followUpSearchFunction = {
    "name": "answer_user_question",
    "description": "Generates a prompt for openai to answer the users question based on their existing external document selections and any documents referenced in their question.",
    "parameters": {
        "type": "object",
        "properties": {
            "user_question": {
                "type": "string",
                "description": "the question posed by the user"
            },
            "specific_documents_referenced": {
                "type": "array",
                "description": "An array of identifiers for any specific documents referenced in the users follow up question",
                "items": {
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "the title of the document referenced by the user"
                        },
                        "guid": {
                            "type": "string",
                            "description": "the guid of the document referenced by the user"
                        },
                        "citation": {
                            "type": "string",
                            "description": "the citation of the document referenced by the user"
                        }
                    }
                }
            }
        },
        "required": ["user_question"],
    }
}

//loadState();

async function submitQuestion(userInput) {
    // Append the question to chat messages




    let userMessages = aiState.chatMessages.filter(msg => msg.type === 'user');
    let responseNum = userMessages.length;  // Number of user responses so far
    let includeInConvo = inRefine || responseNum == 0
        // Show the user's question in the chat box
    appendChatMessage('user', userInput, includeInConvo);

    if (responseNum === 0) {
        question = userInput;
        aiState.currentQuestion = userInput;
        let message = generateQueryAnalysisNLGpt4Message_initial(userInput);
        let functions = [legalSearchFunction, refineQueryFunction]
        let aiResponse = await processWithAzureOpenAI(message, functions, "gpt-4-8k",{"name": "refine_query"});
        if (aiResponse.choices[0].message.function_call && aiResponse.choices[0].message.function_call.name) {
            let functionCalled = aiResponse.choices[0].message.function_call.name;
            if (functionCalled === "get_legal_search_results") {
                inSearch = true;
                inRefine = false;
                await runSearches(aiResponse);
            } else if (functionCalled === "refine_query") {
                inRefine = true;
                inSearch = false;
                await refineQuery(aiResponse);
            }
        } else {
            let aiResponseMessage = aiResponse.choices[0].message.content;
            appendChatMessage('ai', aiResponseMessage);
            inRefine = true;
            inSearch = false;
        }
    }
    else if (responseNum > 0 && inRefine) {
        question += userInput;
        aiState.currentQuestion += userInput;
        let message = generateQueryAnalysisNLGpt4Message_RefineSecondary(userInput);
        let functions = [legalSearchFunction, refineQueryFunction]
        let aiResponse = await processWithAzureOpenAI(message, functions);
        if (aiResponse.choices[0].message.function_call && aiResponse.choices[0].message.function_call.name) {
            let functionCalled = aiResponse.choices[0].message.function_call.name;
            if (functionCalled === "get_legal_search_results" || functionCalled === "get_precision_legal_search_results") {
                inSearch = true;
                inRefine = false;
                await runSearches(aiResponse, true);
            } else if (functionCalled === "refine_query") {
                inRefine = true;
                inSearch = false;
                await refineQuery(aiResponse, false);
            }
        } else {
            let aiResponseMessage = aiResponse.choices[0].message.content;
            appendChatMessage('ai', aiResponseMessage);
            inRefine = true;
            inSearch = false;
        }
    } else {
        inRefine = false;
        inSearch = false;
        let message = generateFollowUpMessage(userInput);
        let functions = [runUserSearchFunction, addToKeepListFunction, followUpSearchFunction, seeMoreRelevantDocumentsFunction];
        let aiResponse = await processWithAzureOpenAI(message, functions);
        if (aiResponse.choices[0].message.function_call && aiResponse.choices[0].message.function_call.name) {
            let functionCalled = aiResponse.choices[0].message.function_call.name;
            let argumentsRaw = aiResponse.choices[0].message.function_call.arguments;
            const jsonString = argumentsRaw.replace(/\n/g, "");
            const arguments = JSON.parse(jsonString);
            if (functionCalled === "add_to_keep_list") {
                let documentsToAddToList = arguments.specific_documents_referenced.map(doc => { return `Title: ${doc.title} \t Citation: ${doc.citation} \t GUID: ${doc.guid}` }).join('<br>');
                let aiResponseMessage = `I've added the following documents to your keep list: <br><br> ${documentsToAddToList}`;
                appendChatMessage('ai', aiResponseMessage);
            } else if (functionCalled === "run_user_search") {
                let aiResponseMessage = `I'm running your requested search. <br><br> <a href="https://${westlawHost}/Search/Results.html?query=${encodeURIComponent(arguments.search_query)}" target="_blank">${arguments.search_query}</a>`;
                appendChatMessage('ai', aiResponseMessage);
                runUserSearch(arguments.search_query);
            }else if (functionCalled === "see_more_relevant_documents") {
                let currentIndex = aiState.displayedPossibleDocuments.length;
                let doc_count = arguments.doc_count && arguments.doc_count > 0 ? arguments.doc_count : 10;
                let isShowingAllDocs = doc_count + currentIndex >= aiState.possibleDocuments.length;
                let aiResponseMessage = `I've added ${!isShowingAllDocs ? doc_count : "all the remaining"} additional documents to the list of relevant documents. You are now seeing ${isShowingAllDocs ? aiState.possibleDocuments.length : doc_count + currentIndex} of ${aiState.possibleDocuments.length} documents<br><br>`;
                aiState.displayedPossibleDocuments.push(...aiState.possibleDocuments.slice(currentIndex, currentIndex + arguments.doc_count));
                aiResponseMessage += getDocumentsContainer();
                appendChatMessage('ai', aiResponseMessage);
                addDocListListeners();
                renderPossibleDocuments();
                renderSelectedDocuments();
                saveState();
            }else if (functionCalled === "answer_user_question") {
                aiState.chatMessages[aiState.chatMessages.length - 1].includeForQA = true;
                let aiResponseMessage = `I'm generating a response to your question: ${arguments.user_question}`;
                if (arguments.specific_documents_referenced) {
                    let documentsToAddToList = arguments.specific_documents_referenced.map(doc => {
                        return `Title: ${doc.title} \t Citation: ${doc.citation}`
                    }).join('<br>');
                    aiResponseMessage += `using the following documents: <br> ${documentsToAddToList}`;
                }

                let aiResponseMessageWithStreamDiv = aiResponseMessage + `<div id="streamResponse${aiState.chatMessages.length}"> </div>`;
                appendChatMessage('ai', aiResponseMessageWithStreamDiv, true, false);

                let message = generateAnswerUserQuestionMessage(arguments.user_question, arguments.specific_documents_referenced);
                let element = document.getElementById(`streamResponse${aiState.chatMessages.length - 1}`);
                await streamChatCompletionWithOpenAI(message, 'gpt-4-32k',1000,0.2,element,aiResponseMessage);
            }
        } else {
            aiState.chatMessages[aiState.chatMessages.length - 1].includeForQA = true;
            let aiResponseMessage = `I'm generating a response...`;

            let aiResponseMessageWithStreamDiv = aiResponseMessage + `<div id="streamResponse${aiState.chatMessages.length}"> </div>`;
            appendChatMessage('ai', aiResponseMessageWithStreamDiv, true, false);

            let message = generateAnswerUserQuestionMessage(userInput, null);
            let element = document.getElementById(`streamResponse${aiState.chatMessages.length - 1}`);
            await streamChatCompletionWithOpenAI(message, 'gpt-4-32k',1000,0.2,element,aiResponseMessage);
        }
    }


}

async function refineQuery(aiResponse, isInitialRequest) {
    let refineMessage = `I ${isInitialRequest ? "" : "still"} need a little more information to help you find what you're looking for. Please answer the following questions so I can better assist you.  Just say 'run searches' if you would like to proceed without entering additional details.<br><br> `;
    let arguments = aiResponse.choices[0].message.function_call.arguments;
    const jsonString = arguments.replace(/\n/g, "");
    const questions = JSON.parse(jsonString);
    refineMessage += (questions.questions_for_user_to_refine_task_definition.join('<br>')).replace(/\n/g, "");
    appendChatMessage('ai', refineMessage);
}

async function runUserSearch(query) {
    let searchingMsg = 'running your search and updating relevant documents...';
    searchingMsg += `<div id="userSearchProgressBarContainer${aiState.chatMessages.length}" style="width: 100%; height: 20px; background-color: #f3f3f3;">
                            <div id="userSearchProgressBar${aiState.chatMessages.length}" style="height: 100%; background-color: #0e568c; width: 0;"></div>
                        </div>`;

    appendChatMessage('ai', searchingMsg);
    progressElement = document.getElementById(`userSearchProgressBar${aiState.chatMessages.length - 1}`);
    progressIterator = 0;
    progressTotal = 4 + 40;
    let searchResult = await getSearchResult(query);
    let searchResultWithEmbeddings = await addEmbeddingsToDocs(searchResult);
    searchResultWithEmbeddings.forEach(doc => {
        doc.isAdded = true;
    });
    aiState.possibleDocuments.push(...searchResultWithEmbeddings);
    aiState.possibleDocuments = aiState.possibleDocuments.filter((doc, index, self) =>
            index === self.findIndex((d) => (
                d.docGuid === doc.docGuid
            ))
    );
    aiState.possibleDocuments = sortBasedOnSimilarity(aiState.possibleDocuments, aiState.currentQuestionEmbedding);
    let currentDisplayedDocGuids = aiState.displayedPossibleDocuments.map(doc => doc.docGuid);

    aiState.displayedPossibleDocuments = aiState.possibleDocuments.slice(0, aiState.displayedPossibleDocuments.length);


    progressIterator = progressTotal -1;
    updateProgressBar();
    progressIterator = 0;
    progressTotal = -1;

    let message = 'I\'ve sorted the search results based on relevance to your question and I\'ve updated the Relevant Documents list below.  Just ask if you would like to add the next most relevant documents from the searches to the displayed list.';
    message +=	getDocumentsContainer();
    appendChatMessage('ai', message);
    renderPossibleDocuments();
}

async function runSearches(aiResponse) {
    let searchingMsg = 'I\'m running the following searches and then I will provide you with the documents most relevant to your question. Click on any of the search queries in order to open the results in your browser.  If you would like to add any additional searches just ask.<br/><br>Search Queries:<br/>';
    let arguments = aiResponse.choices[0].message.function_call.arguments;
    const jsonString = arguments.replace(/\n/g, "");
    const queries = JSON.parse(jsonString).search_queries;
    searchingMsg += queries.map(query =>  {
        return `<a href="https://${westlawHost}/Search/Results.html?query=${encodeURIComponent(query.search_query)}" target="_blank">${query.search_query}</a>`;
    }).join('<br/>');
    appendChatMessage('ai', searchingMsg, true, false);
    searchingMsg = queries.length > 1 ? 'executing searches...' : 'executing search...';
    searchingMsg += `<div id="searchProgressBarContainer" style="width: 100%; height: 20px; background-color: #f3f3f3;">
                            <div id="searchProgressBar" style="height: 100%; background-color: #0e568c; width: 0;"></div>
                        </div>`;
    appendChatMessage('ai', searchingMsg);
    // Call an asynchronous function to simulate getting the AI's response
    // You might want to replace this with a real API call
    let docs = [];
    progressElement = document.getElementById('searchProgressBar');
    progressIterator = 0;
    progressTotal = queries.length * 4 * 2;
    let promises = queries.map(query => getSearchResult(query.search_query, query.states_if_needed));

    try {
        let results = await Promise.all(promises);

        // Combine all the results into one array
        docs = [].concat(...results);
    } catch (err) {
        console.error(err);
    }
    searchingMsg = 'I\'ve retrieved the top 20 case, legislation and secondary source results from each of the above searches. Now I\'m going to rank the documents based by relevance to your question.Here are few of the top search results which you can browse while I rank the full list';
    let uniqueDocuments = docs.filter((doc, index, self) =>
            index === self.findIndex((d) => (
                d.docGuid === doc.docGuid
            ))
    );
    let topDocs = uniqueDocuments.filter(doc => doc.rank == 1);
    let sortedTopDocs = await sortSearchResultsBasedOnEmbeddings(topDocs, aiState.currentQuestion);
    let topDocList = document.createElement('ul');
    sortedTopDocs.slice(0,3).forEach((doc, index) => {
        let listItem = document.createElement('li');
        let innerHTML = `<a href="https://${westlawHost}${doc.docLink}&transitionType=SearchItem&contextData=%28sc.Default%29"> ${doc.title} `;
        if (doc.filedDate) {
            innerHTML += `(${doc.filedDate})`;
        }
        if (doc.jurisdiction) {
            innerHTML += `(${doc.jurisdiction})`;
        }
        innerHTML += `(${doc.resultTypeCode})`
        innerHTML += '</a>';
        listItem.innerHTML = innerHTML;
        topDocList.appendChild(listItem);
    });
    searchingMsg += '<br>Here are a few of the top search results which you can browse while I rank the full list.<br>';
    searchingMsg += topDocList.outerHTML;

    appendChatMessage('ai', searchingMsg);
    progressIterator = progressTotal -1;
    updateProgressBar();
    progressIterator = 0;
    progressTotal = -1;
    searchingMsg = 'ranking documents...';
    searchingMsg += `<div id="rankProgressBarContainer" style="width: 100%; height: 20px; background-color: #f3f3f3;">
                            <div id="rankProgressBar" style="height: 100%; background-color: #0e568c; width: 0;"></div>
                        </div>`;

    appendChatMessage('ai', searchingMsg);

    progressElement = document.getElementById('rankProgressBar');
    progressTotal = uniqueDocuments.length + 1;
    progressIterator = 0;
    let sortedDocs = await sortSearchResultsBasedOnEmbeddings(uniqueDocuments, aiState.currentQuestion);

    getAIResponse(question, sortedDocs).then(response => {
        // Update the chat with the AI's response
        appendChatMessage('ai', response.message);
        var selects = document.getElementsByClassName('sort-select');
        for (let i = 0; i < selects.length; i++) {
            selects[i].value = 'relevance';
        }
        aiState.possibleDocumentSort = 'relevance';
        aiState.possibleDocuments = response.documents;
        aiState.displayedPossibleDocuments = response.documents.slice(0, 20);

        // Update the possible documents list



        renderPossibleDocuments();

        addDocListListeners();
        saveState();

    });
}

async function addEmbeddingsToDocs(docs) {
    let chunkSize = 10;
    let docsWithEmbeddings = [];
// Split docs into chunks of 5 items each
    let chunks = Array(Math.ceil(docs.length / chunkSize)).fill().map((_, index) => index * chunkSize).map(begin => docs.slice(begin, begin + chunkSize));

    for (let chunk of chunks) {
        let promises = chunk.map(async doc => {
            let textForEmbedding = "";
            if (doc.snippets && doc.snippets.length > 0) {
                for (let j = 0; j < doc.snippets.length; j++) {
                    textForEmbedding += doc.snippets[j].snippetFragment.replace(/<[^>]*>/g, '');
                }
            }
            if (doc.summary) {
                textForEmbedding += "\n\n" + doc.summary.replace(/<[^>]*>/g, '');
            }
            doc.textForEmbedding = textForEmbedding;
            return getEmbeddingAzureOpenAI(textForEmbedding);
        });

        try {
            let chunkEmbeddings = await Promise.all(promises);

            // Attach embeddings to docs and push them to the main array
            chunk.forEach((doc, i) => {
                doc.embedding = chunkEmbeddings[i];
                docsWithEmbeddings.push(doc);
            });
            await delay(400);
        } catch (err) {
            console.error(err);
        }
    }
    return docsWithEmbeddings;
}

async function sortSearchResultsBasedOnEmbeddings(docs, question) {
    let docsWithEmbeddings = await addEmbeddingsToDocs(docs);
    let questionEmbedding = await getEmbeddingAzureOpenAI(question);
    aiState.currentQuestionEmbedding = questionEmbedding;
    return sortBasedOnSimilarity(docsWithEmbeddings, questionEmbedding);
}

// Asynchronous function to simulate getting the AI's response
function getAIResponse(question, sortedDocs) {


    let message = 'I\'ve sorted the search results based on relevance to your question and I\'ve added them to the Relevant Documents list below.  Give them a look and add documents you think are authoritative and relevant to your legal issue to the list of selected documents.  I will reference information from the selected documents when answering any questions in the chat.  If you would like to see additional documents just request additional searches and I will add them to the list.';
    message +=	getDocumentsContainer();
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({
                documents: sortedDocs,
                message: message
            });
        }, 10); // Wait 2 seconds to simulate network delay
    });
}

function getDocumentsContainer() {
    return `<div id="documents-container">
                    <h3>Relevant Documents</h3>
                    <select class="sort-select">
                        <option selected="selected" value="relevance">Relevance</option>
                        <option value="date">Date</option>
                        <option value="court">Court Level</option>
                    </select>
                    <ol class="possible-documents">
                        <!-- Possible documents will be inserted here by JavaScript -->
                    </ol>
                    <button class="add-selected-documents">Add Checked Documents to Selections</button>
                
                    <h3>Selected Documents</h3>
                
                    <ul class="selected-documents">
                        <!-- Selected documents will be inserted here by JavaScript -->
                    </ul>
                </div>`
}

// Function to append a chat message
function appendChatMessage(sender, text, includeForQA, isPulse) {
    let chatBox = document.getElementById('chat-container');
    let message = document.createElement('div');
    if (sender === 'ai'&& userElementForPulse || inPulse) {
        userElementForPulse.classList.remove('pulse');
        inPulse = false;
    }
    if (sender === 'user' || isPulse) {
        userElementForPulse = message;
        inPulse = true
        userElementForPulse.classList.add('pulse');
    }

    message.classList.add(sender + '-message');
    message.innerHTML = text;
    chatBox.appendChild(message);
    chatBox.scrollTop = chatBox.scrollHeight;
    aiState.chatMessages.push({
        type: sender,
        text: text.replace('\n', '<br>'),
        question: aiState.chatMessages.length === 1 || (inRefine && sender === 'user'),
        includeForQA: includeForQA
    });
    saveState()
}

function updateProgressBar() {
    if (progressTotal  > 0 && progressIterator <= progressTotal) {
        progressIterator++;
        progressElement.style.width = (progressIterator / progressTotal * 100) + '%';
    }
}

// Function to render the possible documents
function renderPossibleDocuments() {

    let possibleDocumentsLists = document.getElementsByClassName('possible-documents');
    if (possibleDocumentsLists === null || possibleDocumentsLists.length === 0) {
        return;
    }
    let sortElements = document.getElementsByClassName('sort-select');
    for (let i = 0; i < sortElements.length; i++) {
        sortElements[i].value = aiState.possibleDocumentSort;
    }

    sortSelect(aiState.possibleDocumentSort);
    for (let i = 0; i < possibleDocumentsLists.length; i++) {
        possibleDocumentsLists[i].innerHTML = '';
        aiState.displayedPossibleDocuments.forEach((doc, index) => {
            let listItem = document.createElement('li');
            let innerHTML = `<input type="checkbox" id="doc-${index}"><a href="https://${westlawHost}${doc.docLink}&transitionType=SearchItem&contextData=%28sc.Default%29"> ${doc.title} `;
            if (doc.filedDate) {
                innerHTML += `(${doc.filedDate})`;
            }
            if (doc.jurisdiction) {
                innerHTML += `(${doc.jurisdiction})`;
            }
            innerHTML += `(${doc.resultTypeCode})`
            if (doc.isAdded) {
                innerHTML += `(Doc From User Search)`;
            }
            innerHTML += '</a>';
            listItem.innerHTML = innerHTML;
            possibleDocumentsLists[i].appendChild(listItem);
        });
    }
}

function addDocListListeners()
{
    // Rendering possible documents
    let possibleDocumentsContainers = document.getElementsByClassName('possible-documents');
    if (!possibleDocumentsContainers || possibleDocumentsContainers.length === 0) {
        return;
    }
    for (let i = 0; i < possibleDocumentsContainers.length; i++) {
        possibleDocumentsContainers[i].innerHTML = ''; // Clear out the existing documents
        possibleDocumentsContainers[i].addEventListener('click', function (event) {
            if (event.target.tagName === 'A') {
                event.preventDefault();
                navigateToURL(event.target.href);
            }
        });
    }
    renderPossibleDocuments();

    // Rendering selected documents
    let selectedDocumentsContainers = document.getElementsByClassName('selected-documents');
    for (let i = 0; i < possibleDocumentsContainers.length; i++) {
        selectedDocumentsContainers[i].innerHTML = ''; // Clear out the existing documents
        selectedDocumentsContainers[i].addEventListener('click', function (event) {
            if (event.target.tagName === 'A') {
                event.preventDefault();
                navigateToURL(event.target.href);
            }
        });
    }
    renderSelectedDocuments();

    let addSelectedDocumentsButtons = document.getElementsByClassName('add-selected-documents');
    // Add a click event listener to the add selected documents button
    for (let i = 0; i < addSelectedDocumentsButtons.length; i++) {
        addSelectedDocumentsButtons[i].addEventListener('click', function () {
            addSelectedDocuments();
        });
    }

    let sortSelects = document.getElementsByClassName('sort-select');
    for (let i = 0; i < addSelectedDocumentsButtons.length; i++) {
        sortSelects[i].addEventListener('change', function() {
            let sortValue = this.value;
            aiState.possibleDocumentSort = sortValue;
            saveState();
            sortSelect(sortValue);
            renderPossibleDocuments();
        });
        renderPossibleDocuments();
    }
}

function sortSelect(sortValue) {
    aiState.possibleDocumentSort = sortValue;
    switch(sortValue) {
        case 'relevance':
            aiState.displayedPossibleDocuments = aiState.displayedPossibleDocuments.sort((a, b) => {
                return b.similarity - a.similarity;
            });
            break;
        case 'date':
            aiState.displayedPossibleDocuments = aiState.displayedPossibleDocuments.sort((a, b) => {
                let aDate = a.filedDate;
                let bDate = b.filedDate;
                if (!aDate && bDate) {
                    return 1;
                }
                if (!bDate && aDate) {
                    return -1;
                }
                if (!aDate && !bDate) {
                    return 0;
                }
                let aIsALR = aDate.indexOf("ALR") >= 0;
                let bIsALR = bDate.indexOf("ALR") >= 0;
                if (!aIsALR && bIsALR) {
                    return -1;
                }
                if (!bIsALR && aIsALR) {
                    return 1;
                }

                let aDateObject = new Date(aDate);
                let bDateObject = new Date(bDate);
                return aDateObject < bDateObject ? 1 : -1;
            });
            break;
        case 'court':
            aiState.displayedPossibleDocuments = aiState.displayedPossibleDocuments.sort((a, b) => {
                let aCourt = a.jurisdiction;
                let bCourt = b.jurisdiction;
                if (!aCourt && bCourt) {
                    return 1;
                }
                if (!bCourt && aCourt) {
                    return -1;
                }
                if (!bCourt && !aCourt) {
                    return 0;
                }
                let aIsSupreme = aCourt.indexOf("Supreme") >= 0;
                let aIsAppeals = aCourt.indexOf("Appeals") >= 0;
                let aIsDistrict = aCourt.indexOf("District") >= 0;
                let bIsSupreme = bCourt.indexOf("Supreme") >= 0;
                let bIsAppeals = bCourt.indexOf("Appeals") >= 0;
                let bIsDistrict = bCourt.indexOf("District") >= 0;
                if (aIsSupreme && !bIsSupreme) {
                    return -1;
                }
                if (!aIsSupreme && bIsSupreme) {
                    return 1;
                }
                if (aIsAppeals && !bIsAppeals) {
                    return -1;
                }
                if (!aIsAppeals && bIsAppeals) {
                    return 1;
                }
                if (aIsDistrict && !bIsDistrict) {
                    return -1;
                }
                if (!aIsDistrict && bIsDistrict) {
                    return 1;
                }
                return 0;
            });
    }
    saveState();
}


// Function to move selected documents
async function addSelectedDocuments() {
    let checkboxes = document.querySelectorAll('.possible-documents input[type="checkbox"]');
    let indexesToRemove = [];
    let docsToAdd = [];
    checkboxes.forEach( (checkbox, index) => {
        if (checkbox.checked ) {
            // Add to selected
            let modulatedIndex = aiState.displayedPossibleDocuments.length <= index ? index % aiState.displayedPossibleDocuments.length : index;
            docsToAdd.push(aiState.displayedPossibleDocuments[modulatedIndex]);
            let targetGuid = aiState.displayedPossibleDocuments[modulatedIndex].docGuid;
            aiState.possibleDocuments = aiState.possibleDocuments.filter(item => item.docGuid !== targetGuid);
            indexesToRemove.push(modulatedIndex);
        }
    });
    for (let i = indexesToRemove.length - 1; i >= 0; i--) {
        aiState.displayedPossibleDocuments.splice(indexesToRemove[i], 1);
    }
    for (let i = 0; i< docsToAdd.length; i++) {
        docsToAdd[i].snippets.push(...await getAdditionalSnippets(docsToAdd[i]));
        aiState.selectedDocuments.push(docsToAdd[i]);
    }

    // Re-render the lists
    renderPossibleDocuments();
    renderSelectedDocuments();

    // Save state
    saveState();
}

async function getAdditionalSnippets(doc) {
    let startingSnippet = 5;
    let snippets = [];
    let additionalSnippetsUrl = `https://${westlawHost}/Search/v3/search/additionalSnippets?documentGuid=${doc.docGuid}&startingSnippet=${startingSnippet}&resultListGuid=${doc.searchId}&type=CASE&rank=${doc.rank}&contextData=(sc.Search)`;

    let additionalSnippetsResponseRaw = await fetch(additionalSnippetsUrl, {
        method: 'GET', // or 'POST'
        headers: getHeaders()
    });
    let additionalSnippetsResponse = await additionalSnippetsResponseRaw.json();
    if (additionalSnippetsResponse && additionalSnippetsResponse.snippets && additionalSnippetsResponse.snippets.length > 0) {
        additionalSnippetsResponse.snippets.forEach(snippet => {
            snippet.snippetFragment = snippet.xhtmlFragment;
        });
        snippets.push(...additionalSnippetsResponse.snippets);
        startingSnippet = 9;
        additionalSnippetsUrl = `https://${westlawHost}/Search/v3/search/additionalSnippets?documentGuid=${doc.docGuid}&startingSnippet=${startingSnippet}&resultListGuid=${doc.searchId}&type=CASE&rank=${doc.rank}&contextData=(sc.Search)`;

        additionalSnippetsResponseRaw = await fetch(additionalSnippetsUrl, {
            method: 'GET', // or 'POST'
            headers: getHeaders()
        });
        additionalSnippetsResponse = await additionalSnippetsResponseRaw.json();
        if (additionalSnippetsResponse && additionalSnippetsResponse.snippets && additionalSnippetsResponse.snippets.length > 0) {
            additionalSnippetsResponse.snippets.forEach(snippet => {
                snippet.snippetFragment = snippet.xhtmlFragment;
            });
            snippets.push(...additionalSnippetsResponse.snippets);
        }
    }
    return snippets;
}

// Function to render the selected documents
function renderSelectedDocuments() {
    let selectedDocumentsLists = document.getElementsByClassName('selected-documents');
    if (selectedDocumentsLists === null || selectedDocumentsLists.length === 0) {
        return;
    }
    for (let i = 0; i < selectedDocumentsLists.length; i++) {
        selectedDocumentsLists[i].innerHTML = '';
        aiState.selectedDocuments.forEach(doc => {
            let listItem = document.createElement('li');
            let innerHTML = `<a href="https://${westlawHost}${doc.docLink}&transitionType=SearchItem&contextData=%28sc.Default%29"> ${doc.title} `;
            if (doc.filedDate) {
                innerHTML += `(${doc.filedDate})`;
            }
            if (doc.jurisdiction) {
                innerHTML += `(${doc.jurisdiction})`;
            }
            innerHTML += `(${doc.resultTypeCode})`
            innerHTML += '</a>';
            listItem.innerHTML = innerHTML;
            selectedDocumentsLists[i].appendChild(listItem);
        });
    }
}

// Function to clear state
function clearState() {
    aiState = {
        chatMessages: [],
        possibleDocuments: [],
        displayedPossibleDocuments:[],
        possibleDocumentSort: 'relevance',
        selectedDocuments: [],
        currentQuestion: '',
        currentQuestionEmbedding: []
    };

    // Clear the lists and chat box
    document.getElementById('chat-container').innerHTML = '';

    // Save state
    saveState();
    renderState();
}

// Function to save state
function saveState() {
    chrome.storage.local.set({aiState: aiState}, () => {
        if (chrome.runtime.lastError) {
            console.log('Error: ' + chrome.runtime.lastError.message);
        }
        console.log('Value is set to ' + aiState);
    });
    console.log('Saved state');
    console.log(aiState);
    sendStateToBackground();
}

function sendStateToBackground() {
    chrome.runtime.sendMessage({saveAIState: true,aiState: aiState, aiInput:apiKey, aiHeaders:aiHeaders, westlawHost:westlawHost}, function (response) {
    });
}

function renderState() {
    // Rendering chat messages
    let chatContainer = document.getElementById('chat-container');
    chatContainer.innerHTML = ''; // Clear out the existing chat messages

    aiState.chatMessages.forEach(function (message) {
        let chatBubble = document.createElement('div');
        chatBubble.classList.add('chatBubble', message.type + '-message'); // Assuming each message has a 'sender' property that is either 'user' or 'ai'
        chatBubble.innerHTML = message.text;
        chatContainer.appendChild(chatBubble);
    });

    if (!aiState.chatMessages || aiState.chatMessages.length === 0) {

        appendChatMessage('ai', 'Hello! Welcome to the Westlaw AU Assistant!<br><br>You can ask a legal research question and I\'ll provide tools to help speed up your research and collect relevant caselaw, legislation and secondary sources in order to answer the question<br><br>Ask your question as if you are talking to a trusted colleague - add key facts and claims, procedural details, or legal issues/topics to get the best response.');
    }

    // Rendering current research question
    let questionHeader = document.getElementById('research-question');
    questionHeader.textContent = aiState.currentQuestion;
    renderPossibleDocuments();
    renderSelectedDocuments();
    let chatBox = document.getElementById('chat-container');
    chatBox.scrollTop = chatBox.scrollHeight;
}

function loadState() {
    // Attempt to restore state from localStorage
    chrome.storage.local.get('aiInput', function (data) {
        if (data) {
            apiKey = data.aiInput;
            console.log("found ai key");
            chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {aiInput: apiKey});
            });
        }

        chrome.storage.local.get('aiHeaders', function (data) {
            if (data) {
                aiHeaders = data.aiHeaders;
                setHost();
                console.log("found ai headers");
                chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {aiHeaders: aiHeaders});
                });
            }

            chrome.storage.local.get('aiState', function (data) {
                if (data && data.aiState) {
                    console.log("found ai State");

                    aiState = data.aiState;
                    console.log(aiState);
                    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                        chrome.tabs.sendMessage(tabs[0].id, {aiState: aiState});
                    });
                    renderState();
                    addDocListListeners();
                    let chatBox = document.getElementById('chat-container');
                    chatBox.scrollTop = chatBox.scrollHeight;
                } else {
                    // Initialize state if it doesn't exist in localStorage
                    aiState = {
                        chatMessages: [],
                        possibleDocuments: [],
                        displayedPossibleDocuments:[],
                        possibleDocumentSort: 'relevance',
                        selectedDocuments: [],
                        currentQuestion: '',
                        currentQuestionEmbedding: []
                    };
                    renderState();
                }
                sendStateToBackground();
            });


        });
    });

}


document.getElementById('submit_ai_input').addEventListener('click', function () {
    const privateKey = document.getElementById('ai_input').value;
    document.getElementById('ai_input').value = '';
    // Save private key
    chrome.storage.local.set({aiInput: privateKey});
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {aiInput: privateKey});
    });
    apiKey = privateKey;
});


document.getElementById('submit_headers').addEventListener('click', function () {
    aiHeaders = document.getElementById('headers_input').value;
    document.getElementById('headers_input').value = '';
    // Save private key
    chrome.storage.local.set({aiHeaders: aiHeaders});
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {aiHeaders: aiHeaders});
    });
    setHost();
});

async function processWithAzureOpenAI(messages, functions, model = "gpt-4-8k", functionForce) {//"gpt-4-0613") {


   /* const apiEndpoint = 'https://api.openai.com/v1/chat/completions';

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            model: model ? model : "gpt-4-0613",//gpt-3.5-turbo-0613
            max_tokens: 800,
            functions: functions,
            temperature: 0.2
        }),
    });*/

    const apiEndpoint = `https://openai-ras.nonprod.thomsonreuters.com/openai/deployments/${model}/chat/completions?api-version=2023-07-01-preview`;

    let body = functionForce ? {
        messages: messages,
        max_tokens: 800,
        functions: functions,
        temperature: 0.2,
        function_call: functionForce
    } : {
        messages: messages,
        max_tokens: 800,
        functions: functions,
        temperature: 0.2
    }

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify(body),
    });
    return await response.json();
    //const assistantMessage = data.choices[0].message.function_call.arguments;
    //const jsonString = data.replace(/\n/g, "");
    //return JSON.parse(jsonString);
}

async function streamChatCompletionWithOpenAI(messages, model = 'gpt-4-32k', maxTokens = 1000, temperature = 0.2, element, messageMinusElement) {
    /*const apiEndpoint = 'https://api.openai.com/v1/chat/completions';

    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            model: model,//gpt-4-0613
            max_tokens: maxTokens,
            temperature: temperature,
            stream: true
        }),
    })*/
    let isElementCleared = false;
    const apiEndpoint = `https://openai-ras.nonprod.thomsonreuters.com/openai/deployments/${model}/chat/completions?api-version=2023-07-01-preview`;
    const response = await fetch(apiEndpoint, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            //"api-key": `${apiKey}`,
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            messages: messages,
            max_tokens: 800,
            temperature: 0.2,
            stream: true
        }),
    }).then(response => {

        const reader = response.body.getReader();

        reader.read().then(async function process({ done, value }) {
            if (done) {
                console.log('Stream complete');
                aiState.chatMessages[aiState.chatMessages.length - 1].text = messageMinusElement + element.outerHTML;
                saveState();
                return;
            }
            const decoder = new TextDecoder();
            const decodedChunk = decoder.decode(value);
            // Clean up the data
            const lines = decodedChunk
                .split("\n")
                .map((line) => line.replace("data: ", ""))
                .filter((line) => line.length > 0)
                .filter((line) => line !== "[DONE]")
                .map((line) => { try {return JSON.parse(line)}catch(error){return {}}});

            // Destructuring!
            for (const line of lines) {
                if (line.choices && line.choices.length > 0) {
                    const {
                        choices: [
                            {
                                delta: {content},
                            },
                        ],
                    } = line;

                    if (content) {
                        let splitContent = content.split(" ");
                        for (let i = 0; i < splitContent.length; i++) {
                            await delay(35);
                            if (!isElementCleared) {
                                element.innerHTML = "";
                                element.classList.remove('pulse');
                                isElementCleared = true;
                            }
                            element.innerHTML += splitContent[i].replace("\n", "<br><br>").replace("&lt;","<").replace("&gt;",">") + (i < splitContent.length - 1 ? " " : "");
                        }
                    }
                }
            }

            // Read the next chunk
            return reader.read().then(process);
        });
    }).catch(error => console.error(error));
}

function generateQueryAnalysisNLGpt4Message_initial(text) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    const userMessage = `As a Australian legal research expert, you excel at formulating natural language search queries for Westlaw Australia. The question below was provided by a lawyer performing legal research. The question was written as the input to a legal research ai. Use the provided functions to assist the user with the research request.  If the users request requires further definition use the function call which will elicit more details from the user to refine the research task.\n\n Question:\n ${text}`;

    const systemMessage = `
	You are an expert Australian legal researcher who specializes in writing search queries for westlaw in order to answer legal research questions.  Make sure to include relevant refernces to possible statutes which could be applicable.
	`

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

function generateFollowUpMessage(text) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    const userMessage = text;

    let systemMessage = `
	You are an expert Australian legal researcher attempting to help a user answer a legal research question by helping to find relevant documents and answering questions based on provided context.  The user message could be a request to run a search, a request to add a document or set of documents to the users keep list, a request to see more documents or a request to answer a question.  Call the appropriate function to respond to the user message.`;

    if (aiState.selectedDocuments && aiState.selectedDocuments.length > 0) {
        systemMessage +=   `Below are a set of documents that the user might reference in their question. They may refer to them as their selected documents\n\n Reference Documents: \n\n`;
        systemMessage += aiState.selectedDocuments.map((doc, index) => {return `Document ${index}: Title: ${doc.title} \t\t Citation: ${doc.citation} \t\t Guid: ${doc.docGuid}`}).join("\n\n");
    }

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

function generateAnswerUserQuestionMessage(userInput, selectedDocuments) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/

    let systemMessage = `
	You are an expert Australian legal researcher attempting to help a user answer a legal research question using context from a set of documents selected by the user.  Your answer should be in the form of a legal research report.
	You will be provided a set of messages which are a conversation which should end in a question asked by the user for you to answer with a legal research report. Only base your answer on the provided context below.
	Use citations from the provided documents as appropriate. Make the report incredibly detailed and make sure to consider and reference all of the supplied context that is relevant or analogous to the users question or issue`;


    let selectedContextDocuments = [];
    if (selectedDocuments != null && selectedDocuments.length > 0) {
        let docGuids = selectedDocuments.map((doc) => doc.guid);
        selectedContextDocuments = aiState.selectedDocuments.filter((doc) => docGuids.includes(doc.docGuid));
    } else if (aiState.selectedDocuments && aiState.selectedDocuments.length > 0) {
        selectedContextDocuments = aiState.selectedDocuments;
    }

    systemMessage += `Below are a set of documents that the user might reference in their question. They may refer to them as their selected documents\n\n Reference Documents: \n\n`;



    systemMessage += selectedContextDocuments.map((doc, index) => {
        let context = "";
        if (doc.snippets && doc.snippets.length > 0) {
            for (let j = 0; j < doc.snippets.length; j++) {
                context += doc.snippets[j].snippetFragment.replace(/<[^>]*>/g, '');
            }
        }
        if (doc.summary) {
            context += "\n\n" + doc.summary.replace(/<[^>]*>/g, '');
        }
        return `Document:''' Title: ${doc.title} \t\t Citation: ${doc.citation} \t\t Context From Document: ${context}'''`
    }).join("\n'''''''\n");

    let messages = [
        {role: "system", content: systemMessage},
    ];
    messages.push(...getCurrentConversation());
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

function getCurrentConversation() {
    return aiState.chatMessages.filter((message) => message.includeForQA).map((message) => {return {role: message.type == "ai" ? "assistant":"user", content: message.text.replace(/\\n/g, "\n").replace(/\\t/g, "\t")}});
}

function generateQueryAnalysisNLGpt4Message_RefineSecondary() {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`
};
*/
    const systemMessage = `
	You are an expert Australian legal researcher who specializes in writing search queries for westlaw in order to answer legal research questions.  Make sure to include relevant refernces to possible statutes which could be applicable.
	`

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: aiState.chatMessages[1].text.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
        {role: "assistant", content: aiState.chatMessages[2].text.replace(/<[^>]*>/g, '').replace(/\\n/g, "\n").replace(/\\t/g, "\t")}
    ];
    if (aiState.chatMessages.length > 3) {
        for (let i = 3; i < aiState.chatMessages.length; i++) {
            if (i % 2 === 0) {
                messages.push({role: "assistant", content: aiState.chatMessages[i].text.replace(/<[^>]*>/g, '').replace(/\\n/g, "\n").replace(/\\t/g, "\t")});
            } else {
                messages.push({role: "user", content: aiState.chatMessages[i].text.replace(/\\n/g, "\n").replace(/\\t/g, "\t")});
            }
        }
    }

    return messages;
}


function generateDocSummaryMessage(text) {
    /*
// Modify the user message based on the scraped text
const userMessage = `You are an expert legal researcher who specializes in formatting boolean queries for legal research topics on westlaw edge.  Below is a query made by a laywer attempting to do legal research.  Analyze and critique the user query and respond with detailed suggestions/questions to help the lawyer to improve their query. Provide an example improved query based on the feedback provided (if using the /n connector make sure to not include the letter n and instead replace it with the amount of words). User Query:\n ${text} \n Query Analysis, Suggestions and Questions:`;
*/
    const userMessage = `Act a australian legal research expert.  Below is a legal research question and \n\n Question:\n ${text}`;

    const systemMessage = `
	You are an expert australian legal researcher who specializes in writing search queries for westlaw in order to answer legal research questions.  Make sure to include relevant refernces to possible legislation which could be applicable.
	`

    const messages = [
        {role: "system", content: systemMessage},
        {role: "user", content: userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t")},
    ];
    //const messages = [
    //	{ role: "user", content: systemMessage + userMessage.replace(/\\n/g, "\n").replace(/\\t/g, "\t") },
    // ];
    return messages;
}

window.onload = function () {
    loadState();
    let submitQuestionButton = document.getElementById('submit-question');
    let clearStateButton = document.getElementById('clear-state');

    // Add a click event listener to the submit question button
    submitQuestionButton.addEventListener('click', function () {
        let questionInput = document.getElementById('question-input');
        let question = questionInput.value;
        if (question) {
            submitQuestion(question);
            questionInput.value = '';  // Clear the input field
        }
    });



    // Add a click event listener to the clear state button
    clearStateButton.addEventListener('click', function () {
        clearState();
    });

    document.getElementById('chat-container').addEventListener('click', function (event) {
        if (event.target.tagName === 'A') {
            event.preventDefault();
            navigateToURL(event.target.href);
        }
    });
}

async function getSearchResult(query, statesIfNeeded) {
    let jurisdiction = statesIfNeeded && statesIfNeeded.length > 0 ? statesIfNeeded.map(state => state+'-CS-ALL').join(',') : "AU-ALL";
   let createSearchUrl = `https://${westlawHost}/Search/v3/search/start?jurisdiction=${jurisdiction}&jurisdictionCountryCode=AU&type=ALL&spellChecked=true&skipCiteDiscovery=true&skipFindProcessing=true`;
   let postBody = {"query": query, "clientId": "TEST"};

   let createSearchResponseRaw = await fetch(createSearchUrl, {
        method: 'POST', // or 'POST'
        headers: getHeaders(),
        body: JSON.stringify(postBody)
    }); 
    let createSearchResponse = await createSearchResponseRaw.json();
    
    /*
        let createPolledTaskUrl = "https://1.next.qed.westlaw.com/CreatePolledTask";
        postBody = {
            "vertical": "Search",
            "pathAndQuery": "/Search/v4/search/verify?result=" + createSearchResponse.searchguid + "&requestId=1689365224881000&pingOnly=false",
            "bodyData": "\"\"",
            "httpVerb": "GET"
        };

        let createPolledTaskResponseRaw = await fetch(createPolledTaskUrl, {
            method: 'POST', // or 'POST'
            headers: getHeaders(),
            body: JSON.stringify(postBody)
        });
    /*
        let createPolledTaskResponse = await createPolledTaskResponseRaw.json();
        let taskId = createPolledTaskResponse.TaskId;

        let getPolledTaskUrl = "https://1.next.qed.westlaw.com/PolledTaskResult/" + taskId;
        let getPolledTaskResponseRaw =  await fetch(getPolledTaskUrl, {
            method: 'GET', // or 'POST'
            headers: getHeaders(),
        });

        let getPolledTaskResponse = await getPolledTaskResponseRaw.json();

        while (getPolledTaskResponse.Status === "InProgress") {
            await sleep(1000);
            getPolledTaskResponseRaw = getPolledTaskResponseRaw =  await fetch(getPolledTaskUrl, {
                method: 'GET', // or 'POST'
                headers: getHeaders(),
            });
            getPolledTaskResponse = await getPolledTaskResponseRaw.json();
        }

        if (getPolledTaskResponse.Status === "Complete") {*/
    let url = `https://${westlawHost}/Search/v1/results?query=${encodeURIComponent(createSearchResponse.modifiedquery)}&jurisdiction=${jurisdiction}` + "&jurisdictionCountryCode=AU&result=" + createSearchResponse.searchguid + "&searchId=" + createSearchResponse.searchguid + `&FO=true&clientId=TEST&resultsPerPage=20&detailLevel=3&eligibleForDelivery=true`;

    let searchResultPromises = [];
    let docs = [];
    let caseResults = await fetch(url + "&type=AUNZ_CASES", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    });
    let caseResultsJson = await caseResults.json();
    if (caseResultsJson && caseResultsJson.resultSections && caseResultsJson.resultSections.length > 0 && caseResultsJson.resultSections[0].listItems && caseResultsJson.resultSections[0].listItems.length > 0) {
        docs.push(...caseResultsJson.resultSections[0].listItems);
        updateProgressBar();
    }

    searchResultPromises.push( fetch(url + "&type=AUNZ_LEGISLATION", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    }));
    searchResultPromises.push( fetch(url + "&type=AUNZ_ANALYTICAL", {
        method: 'GET', // or 'POST'
        headers: getHeaders(),
    }));

    let searchResultsPromisesResults = await Promise.all(searchResultPromises);
    let searchResultsJsonPromises = [];
    searchResultsPromisesResults.forEach( result => {
        searchResultsJsonPromises.push(result.json());
    });
    let searchResults = await Promise.all(searchResultsJsonPromises);


    searchResults.forEach( result => {
        if (result && result.resultSections && result.resultSections.length > 0 && result.resultSections[0].listItems && result.resultSections[0].listItems.length > 0) {
            docs.push(...result.resultSections[0].listItems);
            updateProgressBar();
        }
    });
    docs.forEach( doc => {
        doc.searchId = createSearchResponse.searchguid;
    })
    return docs;


}

function getHeaders() {
    // Split the string into lines
    let headerLines = aiHeaders.split('\n');

    // Initialize an empty object to hold the headers
    let headersObject = {};

    // Iterate over the lines
    for (let line of headerLines) {
        // Split the line into key and value
        let [key, value] = line.split(': ');

        // If both key and value exist, add them to the headers object
        if (key && value) {
            headersObject[key] = value;
        }
    }
    headersObject["Accept"] = "application/json";
    headersObject["Accept-Language"] = "en-US";
    return headersObject;
}

function setHost() {
       // Split the string into lines
    let headerLines = aiHeaders.split('\n');

    // Initialize an empty object to hold the headers
    let headersObject = {};

    // Iterate over the lines
    for (let line of headerLines) {
        // Split the line into key and value
        let [key, value] = line.split(': ');

        // If both key and value exist, add them to the headers object
        if (key == 'Host') {
            westlawHost = value;
            chrome.storage.local.set({westlawHost: westlawHost});
            chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {westlawHost: westlawHost});
            });
            break;
        }
    }
}

async function getEmbeddingAzureOpenAI(input) {
    //const apiEndpoint = 'https://api.openai.com/v1/embeddings';
    let maxRetry = 5;
    let retries = 0;

    const apiEndpoint = `https://openai-ras.nonprod.thomsonreuters.com/openai/deployments/text-embedding-ada-002/embeddings?api-version=2023-05-15`;



    while (retries < maxRetry) {
        retries++;
        if (retries > 1) {
            await delay(retries * 2000)
        }
        try {
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error('Request timed out')), 10000)
            );
            /*const response = await fetch(apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    //"api-key": `${apiKey}`,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    input: input,
                    model: "text-embedding-ada-002",
                }),
            });*/
            const response = await fetch(apiEndpoint, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    //"api-key": `${apiKey}`,
                    'Authorization': `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    input: input
                }),
            });

            const data = await response.json();
            if (data && data.data && data.data[0] && data.data[0].embedding) {
                updateProgressBar();
                return data.data[0].embedding;
            } else {
                throw new Error('Response did not contain embedding')
            }
        } catch (error) {
            console.log(error);
        }
    }
}

function cosinesim(A, B) {
    var dotproduct = 0;
    var mA = 0;
    var mB = 0;

    for (var i = 0; i < A.length; i++) {
        dotproduct += A[i] * B[i];
        mA += A[i] * A[i];
        mB += B[i] * B[i];
    }

    mA = Math.sqrt(mA);
    mB = Math.sqrt(mB);
    return dotproduct / (mA * mB);
}

function sortBasedOnSimilarity(arr, questionEmbedding) {
    // Calculate similarity and add to each object
    arr = arr.map(item => {
        return {
            ...item,
            similarity: cosinesim(item.embedding, questionEmbedding)
        };
    });

    // Sort array in descending order based on similarity
    arr.sort((a, b) => {
        return b.similarity - a.similarity;
    });

    return arr;
}

function navigateToURL(url) {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {url: url});
    });
}

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.documentObject) {
            console.log("documentObject:");
            console.log(request.documentObject);
            sendResponse({farewell: "goodbye"});
        }
        if (request.sendCurrentState) {
            sendResponse({aiState: aiState, aiInput:apiKey, aiHeaders:aiHeaders, westlawHost:westlawHost});
        }
    }
);

function delay(delayInMilliseconds) {
    // Return a promise
    return new Promise(resolve => {
        // Set up the delay
        setTimeout(resolve, delayInMilliseconds);
    });
}

chrome.storage.onChanged.addListener((changes, namespace) => {
    for (let [key, { oldValue, newValue }] of Object.entries(changes)) {
        console.log(
            `Storage key "${key}" in namespace "${namespace}" changed.`,
            `Old value was "${oldValue}", new value is "${newValue}".`
        );
    }
});