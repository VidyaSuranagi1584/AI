let aiState = {};
let aiInput = "";
let aiHeaders = "";
let westlawHost = "";

chrome.storage.local.get(['headers'], function (result) {
    if (result.headers) {
        chrome.webRequest.onBeforeSendHeaders.addListener(
            function (details) {
                Object.keys(result.headers).forEach(key => {
                    details.requestHeaders.push({name: key, value: result.headers[key]});
                });

                return {requestHeaders: details.requestHeaders};
            },
            {urls: ["<all_urls>"]},
            ["blocking", "requestHeaders"]
        );
    }
});


chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if (request.saveAIState) {
            aiHeaders = request.aiHeaders;
            aiInput = request.aiInput;
            aiState = request.aiState;
            westlawHost = request.westlawHost;
        }
        if (request.getAIBackgroundState) {
            sendResponse({aiState: aiState, aiInput:aiInput, aiHeaders:aiHeaders, westlawHost:westlawHost});
        }
    }
);